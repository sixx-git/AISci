import axios from 'axios';
import type {
  ApiResponse,
  Project,
  ProjectCreate,
  Document,
  ReportGenerationRequest,
  ReportGenerationResult,
  PipelineRunSummary,
  PipelineRunDetail,
} from '@/types';

const api = axios.create({
  baseURL: '/api/v1',
  timeout: 120000, // 2 分钟超时
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error);
    return Promise.reject(error);
  }
);

// ============ 模拟数据 ============
const mockProjects: Project[] = [
  {
    id: '1',
    name: '深度学习优化研究',
    description: '研究如何优化深度学习模型的训练效率',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    status: 'completed',
  },
  {
    id: '2',
    name: '自然语言处理应用',
    description: '探索 NLP 在实际问题中的应用',
    created_at: new Date(Date.now() - 86400000).toISOString(),
    updated_at: new Date().toISOString(),
    status: 'running',
  },
  {
    id: '3',
    name: '计算机视觉研究',
    description: '研究 CV 领域的新算法和应用',
    created_at: new Date(Date.now() - 172800000).toISOString(),
    updated_at: new Date().toISOString(),
    status: 'draft',
  },
];

const mockDocuments: Document[] = [
  {
    id: '1',
    filename: '深度学习入门.pdf',
    file_path: '/storage/documents/1.pdf',
    file_type: 'pdf',
    content: '深度学习基础内容...',
    status: 'processed',
    created_at: new Date().toISOString(),
  },
];

// ============ 项目 API ============
export const projectApi = {
  async list(): Promise<ApiResponse<Project[]>> {
    try {
      const { data } = await api.get('/projects');
      // 后端返回 { list: [...], pagination: {...} }，提取 list 为纯数组
      if (data?.data?.list) {
        data.data = data.data.list;
      }
      return data;
    } catch (error) {
      console.warn('Using mock data for projects');
      return {
        code: 200,
        message: '获取项目列表成功 (模拟数据)',
        data: mockProjects,
        timestamp: new Date().toISOString(),
      };
    }
  },

  async get(projectId: string): Promise<ApiResponse<Project>> {
    try {
      const { data } = await api.get(`/projects/${projectId}`);
      return data;
    } catch (error) {
      console.warn('Using mock data for project');
      const project = mockProjects.find(p => p.id === projectId) || mockProjects[0];
      return {
        code: 200,
        message: '获取项目详情成功 (模拟数据)',
        data: project,
        timestamp: new Date().toISOString(),
      };
    }
  },

  async create(projectData: ProjectCreate): Promise<ApiResponse<Project>> {
    try {
      const { data } = await api.post('/projects', projectData);
      return data;
    } catch (error) {
      console.warn('Using mock data for create project');
      const newProject: Project = {
        id: Date.now().toString(),
        name: projectData.name,
        description: projectData.description,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        status: 'draft',
      };
      mockProjects.push(newProject);
      return {
        code: 200,
        message: '创建项目成功 (模拟数据)',
        data: newProject,
        timestamp: new Date().toISOString(),
      };
    }
  },

  async update(projectId: string, projectData: Partial<ProjectCreate>): Promise<ApiResponse<Project>> {
    try {
      const { data } = await api.put(`/projects/${projectId}`, projectData);
      return data;
    } catch (error) {
      console.warn('Using mock data for update project');
      const project = mockProjects.find(p => p.id === projectId) || mockProjects[0];
      const updatedProject = { ...project, ...projectData, updated_at: new Date().toISOString() };
      return {
        code: 200,
        message: '更新项目成功 (模拟数据)',
        data: updatedProject,
        timestamp: new Date().toISOString(),
      };
    }
  },

  async delete(projectId: string): Promise<ApiResponse<boolean>> {
    try {
      const { data } = await api.delete(`/projects/${projectId}`);
      return data;
    } catch (error) {
      console.warn('Using mock data for delete project');
      const idx = mockProjects.findIndex(p => p.id === projectId);
      if (idx !== -1) {
        mockProjects.splice(idx, 1);
      }
      return {
        code: 200,
        message: '删除项目成功 (模拟数据)',
        data: true,
        timestamp: new Date().toISOString(),
      };
    }
  },
};

// ============ 文档 API ============
export const documentApi = {
  async upload(projectId: string, file: File): Promise<ApiResponse<Document>> {
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('project_id', projectId);

      const { data } = await api.post('/documents', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return data;
    } catch (error) {
      console.warn('Using mock data for upload document');
      const newDoc: Document = {
        id: Date.now().toString(),
        filename: file.name,
        file_path: `/storage/documents/${Date.now()}.${file.name.split('.').pop()}`,
        file_type: file.type,
        content: '文档内容...',
        status: 'processed',
        created_at: new Date().toISOString(),
      };
      mockDocuments.push(newDoc);
      return {
        code: 200,
        message: '上传文档成功 (模拟数据)',
        data: newDoc,
        timestamp: new Date().toISOString(),
      };
    }
  },

  async list(projectId: string): Promise<ApiResponse<Document[]>> {
    try {
      const { data } = await api.get(`/documents?project_id=${projectId}`);
      return data;
    } catch (error) {
      console.warn('Using mock data for document list');
      return {
        code: 200,
        message: '获取文档列表成功 (模拟数据)',
        data: mockDocuments,
        timestamp: new Date().toISOString(),
      };
    }
  },

  async get(docId: string): Promise<ApiResponse<Document>> {
    try {
      const { data } = await api.get(`/documents/${docId}`);
      return data;
    } catch (error) {
      console.warn('Using mock data for document');
      const doc = mockDocuments.find(d => d.id === docId) || mockDocuments[0];
      return {
        code: 200,
        message: '获取文档详情成功 (模拟数据)',
        data: doc,
        timestamp: new Date().toISOString(),
      };
    }
  },

  async delete(docId: string): Promise<ApiResponse<boolean>> {
    try {
      const { data } = await api.delete(`/documents/${docId}`);
      return data;
    } catch (error) {
      console.warn('Using mock data for delete document');
      const idx = mockDocuments.findIndex(d => d.id === docId);
      if (idx !== -1) {
        mockDocuments.splice(idx, 1);
      }
      return {
        code: 200,
        message: '删除文档成功 (模拟数据)',
        data: true,
        timestamp: new Date().toISOString(),
      };
    }
  },
};

// ============ 研究 Pipeline API ============
export const researchApi = {
  async runPipeline(projectId: string, researchQuestion: string): Promise<ApiResponse<any>> {
    try {
      const { data } = await api.post('/research/run', {
        project_id: projectId,
        research_question: researchQuestion,
      });
      return data;
    } catch (error) {
      console.warn('Using mock data for pipeline');
      return {
        code: 200,
        message: '运行 Pipeline 成功 (模拟数据)',
        data: {
          pipeline: 'completed',
          stages: [],
          summary: '研究完成！这是模拟结果。',
        },
        timestamp: new Date().toISOString(),
      };
    }
  },

  async generateReport(reportData: ReportGenerationRequest): Promise<ApiResponse<ReportGenerationResult>> {
    try {
      const { data } = await api.post('/reports/generate', reportData);
      return data;
    } catch (error) {
      console.warn('Using mock data for report');
      return {
        code: 200,
        message: '生成报告成功 (模拟数据)',
        data: {
          report_id: 'mock-report-1',
          title: 'AI Research Report',
          paper_title: 'AI Research Report',
          paper_abstract: '这是一份模拟研究报告',
          markdown_content: '# Mock Report\n\nThis is a mock report.',
          chapters: {},
          summary: '这是一份模拟报告',
          pdf_url: '#',
        },
        timestamp: new Date().toISOString(),
      };
    }
  },
};

// ============ Pipeline 历史记录 API ============
export const pipelineApi = {
  async run(projectId: string, researchQuestion: string): Promise<ApiResponse<any>> {
    const { data } = await api.post('/pipeline/run', {
      project_id: projectId,
      research_question: researchQuestion,
    });
    return data;
  },

  async getRuns(projectId: string): Promise<ApiResponse<PipelineRunSummary[]>> {
    try {
      const { data } = await api.get(`/pipeline/runs/${projectId}`);
      return data;
    } catch (error) {
      console.warn('Using mock data for pipeline runs');
      return {
        code: 200,
        message: '获取运行历史成功 (模拟数据)',
        data: [],
        timestamp: new Date().toISOString(),
      };
    }
  },

  async getRunDetail(runId: string, projectId?: string): Promise<ApiResponse<PipelineRunDetail>> {
    try {
      const { data } = await api.get(`/pipeline/run/${runId}`);
      return data;
    } catch (error) {
      console.warn('Using mock data for pipeline run detail');
      return {
        code: 200,
        message: '获取运行详情成功 (模拟数据)',
        data: {
          id: 'mock',
          run_id: 'mock',
          project_id: projectId || 'mock',
          research_question: '模拟研究问题',
          status: 'completed',
          created_at: new Date().toISOString(),
          stages: [],
        },
        timestamp: new Date().toISOString(),
      };
    }
  },
};

export default api;
